import pandas as pd
from sklearn import metrics #Import scikit-learn metrics module for accuracy calculation
from sklearn.model_selection import train_test_split # Import train_test_split function
from sklearn.tree import DecisionTreeClassifier # Import Decision Tree Classifier
import random

# load dataset
data = pd.read_csv("filmovi_podaci.csv")

# creating copy of data for cleaning purpose
clean_data = data.copy()

# pravimo dodatnu kolonu gdje trazimo samo filmove koji su odredjenih zanrova i to se pretvara u kolonu dje 1 predstvalja da
# jeste taj zanr, a 0 da nije
genre_list = ['Comedy', 'Romance', 'Horror']
genre_pattern = '|'.join(genre_list)
clean_data['zanr'] = clean_data['genre'].str.contains(genre_pattern).astype(int)

# isto kao prethodni dio samo sto sad radimo sa rating
clean_data['ocjena'] = (clean_data['vote_average']>7)*1

# creating the target variable of the data for modeling
y = clean_data[['zanr']].copy()
y['ocjena'] = clean_data['ocjena']

# creating list of independent features
list = ['id']

# creating copy of clean data to new dataset x which only consist of columns in the list
X = clean_data[list].copy()

# splitting data in test and train
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=324)
# the classifier was made for making decision tree and to train the data using classifier

# fitting decision tree model on data
classifier = DecisionTreeClassifier(max_leaf_nodes=9, random_state=324)
classifier.fit(X_train, y_train)

# predicting values on test set
y_predicted = classifier.predict(X_test)

# checking test accuracy
metrics.accuracy_score(y_test, y_predicted)*100

# Predict chosen movie title
chosen_movies = []
for i in range(len(X_test)):
    if any(y_predicted[i] == 1):
        # Check if the predicted label is 1 (indicating the movie is predicted as given genre)
        # If yes, then append the id of the corresponding sample to the chosen_movie_titles list
        chosen_movies.append(clean_data.loc[X_test.index[i], 'id'])

# posto smo dobili samo id filmova ovdje od id dobijamo naziv filmova
df = pd.read_csv('filmovi_podaci.csv')

# filter dataframe to only include chosen_movies
filmovi = df[df['id'].isin(chosen_movies)]

# create a list of original_title values from the filtered dataframe
lista = filmovi['original_title'].tolist()

# generate a list of 4 random movie titles from the filmovi list
random_value = random.choices(lista, k=4)

print(random_value)