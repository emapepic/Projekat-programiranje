import tkinter as tk
from tkinter import messagebox
from PIL import ImageTk, Image
import pandas as pd
from sklearn import metrics #Import scikit-learn metrics module for accuracy calculation
from sklearn.model_selection import train_test_split # Import train_test_split function
from sklearn.tree import DecisionTreeClassifier # Import Decision Tree Classifier
import random
import re

window = tk.Tk()
window.geometry('1050x700')
window.title("Movie recommendation")

label = tk.Label(window, text="Izaberite do 4 filma od ponuđenih", font=('16'))
label.pack()

frame = tk.Frame(window)
frame.columnconfigure(0, weight = 1)
frame.columnconfigure(1, weight = 1)
frame.columnconfigure(2, weight = 1)
frame.columnconfigure(3, weight = 1)
frame.columnconfigure(4, weight = 1)

film1 = Image.open("avengers infinity wars.jpg")
resized1 = film1.resize((200,250), Image.ANTIALIAS)
new1 = ImageTk.PhotoImage(resized1)
label_1 = tk.Label(frame, image=new1)
label_1.grid(row=0, column=0)

film2 = Image.open("home alone 2.jpg")
resized2 = film2.resize((200,250), Image.ANTIALIAS)
new2 = ImageTk.PhotoImage(resized2)
label_2 = tk.Label(frame, image=new2)
label_2.grid(row=0, column=1)

film3 = Image.open("interstellar.jpg")
resized3 = film3.resize((200,250), Image.ANTIALIAS)
new3 = ImageTk.PhotoImage(resized3)
label_3 = tk.Label(frame, image=new3)
label_3.grid(row=0, column=2)

film4 = Image.open("JOKER.jpg")
resized4 = film4.resize((200,250), Image.ANTIALIAS)
new4 = ImageTk.PhotoImage(resized4)
label_4 = tk.Label(frame, image=new4)
label_4.grid(row=0, column=3)

film5 = Image.open("La La Land.jpg")
resized5 = film5.resize((200,250), Image.ANTIALIAS)
new5 = ImageTk.PhotoImage(resized5)
label_5 = tk.Label(frame, image=new5)
label_5.grid(row=0, column=4)

film6 = Image.open("scream-movie-poster.webp")
resized6 = film6.resize((200,250), Image.ANTIALIAS)
new6 = ImageTk.PhotoImage(resized6)
label_6 = tk.Label(frame, image=new6)
label_6.grid(row=2, column=0)

film7 = Image.open("social network.jpg")
resized7= film7.resize((200,250), Image.ANTIALIAS)
new7 = ImageTk.PhotoImage(resized7)
label_7 = tk.Label(frame, image=new7)
label_7.grid(row=2, column=1)

film8 = Image.open("the matrix.jpg")
resized8 = film8.resize((200,250), Image.ANTIALIAS)
new8 = ImageTk.PhotoImage(resized8)
label_8 = tk.Label(frame, image=new8)
label_8.grid(row=2, column=2)

film9 = Image.open("the truman show.jpg")
resized9 = film9.resize((200,250), Image.ANTIALIAS)
new9 = ImageTk.PhotoImage(resized9)
label_9 = tk.Label(frame, image=new9)
label_9.grid(row=2, column=3)

film10 = Image.open("TITANIC.jpg")
resized10 = film10.resize((200,250), Image.ANTIALIAS)
new10 = ImageTk.PhotoImage(resized10)
label_10 = tk.Label(frame, image=new10)
label_10.grid(row=2, column=4)

# Define movie names and genres in a list of dictionaries
movies1 = [ {"name": "Avengers: Infinity War", "genre": "Romance, Drama"}, 
           {"name": "Home Alone 2: Lost in New York", "genre": "Comedy, Drama, Adventure"}, 
           {"name": "Interstellar", "genre": "Adventure, Drama, Science Fiction"}, 
           {"name": "Joker", "genre": "Crime, Thriller, Drama"},
             {"name": "La La Land", "genre": "Romance, Comedy, Drama, Music"}]
movies2 = [{"name": "Scream", "genre": "Crime, Horror, Mystery"},
            {"name": "The Social Network", "genre": "Drama"},
              {"name": "The Matrix", "genre": "Action, Science Fiction"}, 
              {"name": "The Truman Show", "genre": "Comedy, Drama"},  
                  {"name": "Titanic", "genre": "Romance, Drama"}]

# Create a list to hold the check buttons
check_buttons1 = []
check_buttons2 = []

# Create variables to hold the check button states
check_states1 = [tk.BooleanVar() for _ in range(len(movies1))]
check_states2 = [tk.BooleanVar() for _ in range(len(movies2))]

# Create the check buttons and labels using a loop
for i, movie in enumerate(movies1):
    check_button1 = tk.Checkbutton(frame, text=movie["name"], variable=check_states1[i])
    check_buttons1.append(check_button1)
    check_buttons1[i].grid(row=1, column=i)

for i, movie in enumerate(movies2):
    check_button2 = tk.Checkbutton(frame, text=movie["name"], variable=check_states2[i])
    check_buttons2.append(check_button2)
    check_buttons2[i].grid(row=3, column=i)

def dugme():
    list = []
    for state in check_states1:
        if state.get() == 1:
            list.append(movies1[check_states1.index(state)]['genre'])
    
    for state in check_states2:
        if state.get() == 1:
            list.append(movies2[check_states2.index(state)]['genre'])

    # load dataset
    data = pd.read_csv("filmovi_podaci.csv")

    # creating copy of data for cleaning purpose
    clean_data = data.copy()

    # pravimo dodatnu kolonu gdje trazimo samo filmove koji su odredjenih zanrova i to se pretvara u kolonu dje 1 predstvalja da
    # jeste taj zanr, a 0 da nije
    genre_list = str(list).split(',')
    genre_pattern = '|'.join(genre_list)
    clean_data['zanr'] = clean_data['genre'].str.contains(genre_pattern).astype(int)

    # isto kao prethodni dio samo sto sad radimo sa rating
    clean_data['ocjena'] = (clean_data['vote_average']>7)*1

    # creating the target variable of the data for modeling
    y = clean_data[['zanr']].copy()
    y['ocjena'] = clean_data['ocjena']

    # creating list of independent features
    list = ['id']

    # creating copy of clean data to new dataset x which only consist of columns in the list
    X = clean_data[list].copy()

    # splitting data in test and train
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=324)
    # the classifier was made for making decision tree and to train the data using classifier

    # fitting decision tree model on data
    classifier = DecisionTreeClassifier(max_leaf_nodes=9, random_state=324)
    classifier.fit(X_train, y_train)

    # predicting values on test set
    y_predicted = classifier.predict(X_test)

    # checking test accuracy
    print(metrics.accuracy_score(y_test, y_predicted)*100)

    # Predict chosen movie title
    chosen_movies = []
    for i in range(len(X_test)):
        if any(y_predicted[i] == 1):
            # Check if the predicted label is 1 (indicating the movie is predicted as given genre)
            # If yes, then append the id of the corresponding sample to the chosen_movie_titles list
            chosen_movies.append(clean_data.loc[X_test.index[i], 'id'])

    # posto smo dobili samo id filmova odje od id dobijamo naziv filmova
    df = pd.read_csv('filmovi_podaci.csv')

    # filter dataframe to only include chosen_movie_titles
    filmovi = df[df['id'].isin(chosen_movies)]

    # create a list of original_title values from the filtered dataframe
    lista = filmovi['original_title'].tolist()

    # generate a list of 4 random movie titles from the filmovi list
    random_value = random.choices(lista, k=4)

    # Initialize a list to store the movie titles with their additional information
    movies_with_info = []
    
    # Iterate over the randomly selected movies and retrieve genre, runtime, and release date
    for movie_title in random_value:
        movie_info = filmovi[filmovi['original_title'] == movie_title]
        genre = movie_info['genre'].values[0] 
        genre = re.sub(r"[\[\]']", '', genre)  # Remove square brackets and single quotes from genre
        runtime = movie_info['runtime'].values[0] 
        release_date = movie_info['release_date'].values[0] 
        movies_with_info.append(f"{movie_title} - {genre}, {runtime} min, {release_date}\n")

    message = "\n".join(movies_with_info)
    messagebox.showinfo(title="Preporučeni filmovi", message=message)


button = tk.Button(frame, text='Preporuči', font=('16'), height=2, width=12, command=dugme)
button.grid(row= 4, column=2, pady=20)

def uncheck_all():
    for checkbox in check_buttons1:
        checkbox.deselect()
    for checkbox in check_buttons2:
        checkbox.deselect()

button2 = tk.Button(frame, text='Refresh', font=('16'), command=uncheck_all)
button2.grid(row= 4, column=4, pady=20)

frame.pack()

window.mainloop()